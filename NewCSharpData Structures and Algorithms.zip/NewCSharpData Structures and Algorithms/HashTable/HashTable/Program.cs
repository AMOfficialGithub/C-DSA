﻿using System;
using System.Collections;

class Program
{
    static void Main()
    {
        // Create a hashtable
        Hashtable hashtable = new Hashtable();

        // Add key-value pairs to the hashtable
        hashtable.Add("one", 1);
        hashtable.Add("two", 2);
        hashtable.Add("three", 3);

        // Check if a key exists
        if (hashtable.ContainsKey("two"))
        {
            Console.WriteLine("Key 'two' exists with value: " + hashtable["two"]); // Output: 2
        }

        // Check if a value exists
        if (hashtable.ContainsValue(3))
        {
            Console.WriteLine("Value 3 exists in the hashtable");
        }

        // Remove a key-value pair
        hashtable.Remove("two");

        // Try to access the removed key
        if (!hashtable.ContainsKey("two"))
        {
            Console.WriteLine("Key 'two' has been removed");
        }

        // Iterate over key-value pairs
        foreach (DictionaryEntry entry in hashtable)
        {
            Console.WriteLine($"{entry.Key}: {entry.Value}");
        }

        // Get the number of key-value pairs
        Console.WriteLine("Number of elements: " + hashtable.Count); // Output: 2

        // Clear the hashtable
        hashtable.Clear();
        Console.WriteLine("Hashtable cleared. Number of elements: " + hashtable.Count); // Output: 0
    }
}

