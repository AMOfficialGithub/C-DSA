﻿using System;

public class LinearProbingHashTable<TKey, TValue>
{
    // Array to store keys
    private TKey[] keys;
    // Array to store values
    private TValue[] values;
    // Current number of key-value pairs
    private int count;
    // Capacity of the hash table
    private int capacity;

    // Constructor to initialize the hash table with a default capacity
    public LinearProbingHashTable(int capacity = 16)
    {
        this.capacity = capacity;
        keys = new TKey[capacity];
        values = new TValue[capacity];
        count = 0;
    }

    // Property to get the current number of key-value pairs in the hash table
    public int Count => count;

    // Hash function to calculate the index for a given key
    private int Hash(TKey key)
    {
        return (key.GetHashCode() & 0x7fffffff) % capacity;
    }

    // Method to insert a key-value pair into the hash table
    public void Insert(TKey key, TValue value)
    {
        // Resize the hash table if the load factor exceeds 50%
        if (count >= capacity / 2)
        {
            Resize(2 * capacity);
        }

        // Calculate the index using the hash function
        int index = Hash(key);
        // Use linear probing to find the next available slot
        while (keys[index] != null && !keys[index].Equals(key))
        {
            index = (index + 1) % capacity;
        }

        // If the slot is empty, increment the count
        if (keys[index] == null)
        {
            count++;
        }

        // Insert the key-value pair
        keys[index] = key;
        values[index] = value;
    }

    // Method to search for a value by its key
    public TValue Search(TKey key)
    {
        // Calculate the index using the hash function
        int index = Hash(key);
        // Use linear probing to find the key
        while (keys[index] != null)
        {
            if (keys[index].Equals(key))
            {
                return values[index];
            }
            index = (index + 1) % capacity;
        }
        // Return the default value if the key is not found
        return default(TValue);
    }

    // Method to delete a key-value pair by its key
    public void Delete(TKey key)
    {
        // Calculate the index using the hash function
        int index = Hash(key);
        // Use linear probing to find the key
        while (keys[index] != null)
        {
            if (keys[index].Equals(key))
            {
                // Set the slot to the default value to remove the key-value pair
                keys[index] = default(TKey);
                values[index] = default(TValue);
                count--;
                // Rehash the table to ensure proper linear probing sequence
                Rehash();
                return;
            }
            index = (index + 1) % capacity;
        }
    }

    // Method to rehash the table after a deletion
    private void Rehash()
    {
        TKey[] oldKeys = keys;
        TValue[] oldValues = values;
        keys = new TKey[capacity];
        values = new TValue[capacity];
        count = 0;

        // Reinsert all existing key-value pairs
        for (int i = 0; i < oldKeys.Length; i++)
        {
            if (oldKeys[i] != null)
            {
                Insert(oldKeys[i], oldValues[i]);
            }
        }
    }

    // Method to resize the hash table when the load factor exceeds 50%
    private void Resize(int newCapacity)
    {
        // Create a temporary hash table with the new capacity
        LinearProbingHashTable<TKey, TValue> temp = new LinearProbingHashTable<TKey, TValue>(newCapacity);
        for (int i = 0; i < capacity; i++)
        {
            if (keys[i] != null)
            {
                temp.Insert(keys[i], values[i]);
            }
        }
        // Update the keys, values, and capacity with the new values
        keys = temp.keys;
        values = temp.values;
        capacity = newCapacity;
    }
}

class Program
{
    static void Main()
    {
        // Create a hash table
        LinearProbingHashTable<string, int> hashTable = new LinearProbingHashTable<string, int>();

        // Insert key-value pairs into the hash table
        hashTable.Insert("one", 1);
        hashTable.Insert("two", 2);
        hashTable.Insert("three", 3);

        // Search for values by their keys
        Console.WriteLine("Value for 'one': " + hashTable.Search("one")); // Output: 1
        Console.WriteLine("Value for 'two': " + hashTable.Search("two")); // Output: 2
        Console.WriteLine("Value for 'three': " + hashTable.Search("three")); // Output: 3

        // Delete a key-value pair by its key
        hashTable.Delete("two");

        // Try to search for the deleted key
        Console.WriteLine("Value for 'two' after deletion: " + hashTable.Search("two")); // Output: 0 (default value)
    }
}

