﻿using System;

class Program
{
    static void Main()
    {
        int[] intArray = { 20, 35, -15, 7, 55, 1, -22 };

        // Iterating through the loop
        for (int i = 0; i < intArray.Length; i++)
        {
            // Printing out the values with index i
            Console.WriteLine(intArray[i]);
        }

        // Passing the array to sort
        QuickSort(intArray, 0, intArray.Length);

        Console.WriteLine("Sorted Array:");

        // Print sorted array
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]);
        }
    }

    static void QuickSort(int[] input, int start, int end)
    {
        // If less than 2 then it's a 1 element array, just return. If more, figure out
        // where the pivot is at where the array is sorted
        if (end - start < 2)
        {
            return;
        }
        // Returning the position of the pivot and everything to the left will be small, to right large
        int pivotIndex = Partition(input, start, end);
        // Quick Sorting the left array
        QuickSort(input, start, pivotIndex);
        // Quick sorting the right array
        QuickSort(input, pivotIndex + 1, end);
    }

    static int Partition(int[] input, int start, int end)
    {
        // Using the first element as the pivot
        int pivot = input[start];
        int i = start; // From left to right
        int j = end; // From right to left
        // Stop i and j from crossing
        while (i < j)
        {
            // EMPTY LOOP BODY
            while (i < j && input[--j] >= pivot) ;
            if (i < j)
            {
                input[i] = input[j];
            }

            // EMPTY LOOP
            while (i < j && input[++i] <= pivot) ;
            if (i < j)
            {
                input[j] = input[i];
            }
        }

        input[j] = pivot;
        return j;
    }
}
