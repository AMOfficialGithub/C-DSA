﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Create a stack with the built in Stack Class
        Stack<int> stack = new Stack<int>();

        // Push elements onto the stack
        stack.Push(10);
        stack.Push(20);
        stack.Push(30);

        // Peek at the top element
        Console.WriteLine("Top element: " + stack.Peek()); // Output: 30

        // Pop elements from the stack
        Console.WriteLine("Popped: " + stack.Pop()); // Output: 30
        Console.WriteLine("Popped: " + stack.Pop()); // Output: 20

        // Check if the stack is empty
        Console.WriteLine("Is stack empty? " + (stack.Count == 0)); // Output: False

        // Pop the last element
        Console.WriteLine("Popped: " + stack.Pop()); // Output: 10

        // Check if the stack is empty
        Console.WriteLine("Is stack empty? " + (stack.Count == 0)); // Output: True

        // Clear the stack
        stack.Clear();
        Console.WriteLine("Stack cleared. Is stack empty? " + (stack.Count == 0)); // Output: True
    }
}

