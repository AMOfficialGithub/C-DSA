﻿using System;

namespace Radix
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Initializing an array of strings to be sorted
            string[] radixArray = { "bcdef", "dbaqc", "abcde", "omadd", "bbbb" };

            // Iterating through the UNSORTED array and printing its values
            Console.WriteLine("Unsorted Array:");
            for (int i = 0; i < radixArray.Length; i++)
            {
                Console.WriteLine(radixArray[i]);
            }

            // Find the maximum length of the strings
            int maxLength = 0;
            foreach (string str in radixArray)
            {
                if (str.Length > maxLength)
                {
                    maxLength = str.Length;
                }
            }

            // Perform radix sort on the array
            RadixSort(radixArray, maxLength);

            // Iterating through the SORTED array and printing its values
            Console.WriteLine("\nSorted Array:");
            for (int i = 0; i < radixArray.Length; i++)
            {
                Console.WriteLine(radixArray[i]);
            }
        }

        // Method to perform radix sort on an array of strings
        public static void RadixSort(string[] input, int width)
        {
            // Sorting the array based on each character position, starting from the least significant position
            for (int i = width - 1; i >= 0; i--)
            {
                RadixSingleSort(input, i);
            }
        }

        // Method to perform a single pass of counting sort based on a specific character position
        public static void RadixSingleSort(string[] input, int position)
        {
            int numItems = input.Length;
            int radix = 256; // Number of possible ASCII characters
            int[] countArray = new int[radix + 1];

            // Counting occurrences of each character at the given position
            foreach (string value in input)
            {
                char charAtPos = position < value.Length ? value[position] : '\0';
                countArray[charAtPos + 1]++;
            }

            // Adjusting the count array to accumulate the counts
            for (int j = 1; j < countArray.Length; j++)
            {
                countArray[j] += countArray[j - 1];
            }

            // Creating a temporary array to store sorted values
            string[] temp = new string[numItems];
            for (int tempIndex = numItems - 1; tempIndex >= 0; tempIndex--)
            {
                char charAtPos = position < input[tempIndex].Length ? input[tempIndex][position] : '\0';
                temp[--countArray[charAtPos + 1]] = input[tempIndex];
            }

            // Copying the sorted values back into the original array
            for (int tempIndex = 0; tempIndex < numItems; tempIndex++)
            {
                input[tempIndex] = temp[tempIndex];
            }
        }
    }
}
