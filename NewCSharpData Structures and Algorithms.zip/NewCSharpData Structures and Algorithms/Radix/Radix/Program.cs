﻿namespace Radix
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Initializing an array of integers to be sorted
            int[] radixArray = { 4765, 4568, 1130, 8792, 1594, 5738 };

            // Iterating through the UNSORTED array and printing its values
            Console.WriteLine("Unsorted Array:");
            for (int i = 0; i < radixArray.Length; i++)
            {
                Console.WriteLine(radixArray[i]);
            }

            // Performing radix sort on the array
            radixSort(radixArray, 10, 4);

            // Iterating through the SORTED array and printing its values
            Console.WriteLine("\nSorted Array:");
            for (int i = 0; i < radixArray.Length; i++)
            {
                Console.WriteLine(radixArray[i]);
            }
        }

        // Method to perform radix sort on an array
        public static void radixSort(int[] input, int radix, int width)
        {
            // Sorting the array based on each digit, starting from the least significant digit
            for (int i = 0; i < width; i++)
            {
                RadixSingleSort(input, i, radix);
            }
        }

        // Method to perform a single pass of counting sort based on a specific digit position
        public static void RadixSingleSort(int[] input, int position, int radix)
        {
            int numItems = input.Length;
            int[] countArray = new int[radix];

            // Counting occurrences of each digit at the given position
            foreach (int value in input)
            {
                countArray[GetDigit(position, value, radix)]++;
            }

            // Adjusting the count array to accumulate the counts
            for (int j = 1; j < radix; j++)
            {
                countArray[j] += countArray[j - 1];
            }

            // Creating a temporary array to store sorted values
            int[] temp = new int[numItems];
            for (int tempIndex = numItems - 1; tempIndex >= 0; tempIndex--)
            {
                temp[--countArray[GetDigit(position, input[tempIndex], radix)]] = input[tempIndex];
            }

            // Copying the sorted values back into the original array
            for (int tempIndex = 0; tempIndex < numItems; tempIndex++)
            {
                input[tempIndex] = temp[tempIndex];
            }
        }

        // Method to get the digit at a specific position in a number
        public static int GetDigit(int position, int value, int radix)
        {
            // Calculating the digit by dividing and modding the value
            return value / (int)Math.Pow(10, position) % radix;
        }
    }
}
