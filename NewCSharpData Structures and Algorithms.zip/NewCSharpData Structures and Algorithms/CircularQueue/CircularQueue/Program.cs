﻿using System;

public class CircularQueue<T>
{
    // Array to store the elements of the queue
    private T[] _queue;

    // Pointers for the front and rear of the queue
    private int _front;
    private int _rear;

    // Counter for the number of elements in the queue
    private int _count;

    // Capacity of the queue
    private int _capacity;

    // Constructor to initialize the queue with a given capacity
    public CircularQueue(int capacity)
    {
        _capacity = capacity;
        _queue = new T[capacity];
        _front = 0;
        _rear = -1;
        _count = 0;
    }

    // Property to check if the queue is empty
    public bool IsEmpty => _count == 0;

    // Property to check if the queue is full
    public bool IsFull => _count == _capacity;

    // Property to get the number of elements in the queue
    public int Count => _count;

    // Method to add an element to the end of the queue
    public void Enqueue(T item)
    {
        if (IsFull)
        {
            throw new InvalidOperationException("Queue is full");
        }

        // Increment the rear pointer in a circular manner
        _rear = (_rear + 1) % _capacity;

        // Add the new element to the queue
        _queue[_rear] = item;

        // Increment the count of elements in the queue
        _count++;
    }

    // Method to remove and return the element at the front of the queue
    public T Dequeue()
    {
        if (IsEmpty)
        {
            throw new InvalidOperationException("Queue is empty");
        }

        // Get the element at the front of the queue
        T item = _queue[_front];

        // Increment the front pointer in a circular manner
        _front = (_front + 1) % _capacity;

        // Decrement the count of elements in the queue
        _count--;

        // Return the removed element
        return item;
    }

    // Method to return the element at the front of the queue without removing it
    public T Peek()
    {
        if (IsEmpty)
        {
            throw new InvalidOperationException("Queue is empty");
        }

        // Return the front element
        return _queue[_front];
    }
}

class Program
{
    static void Main()
    {
        // Create a circular queue with a capacity of 5
        CircularQueue<int> queue = new CircularQueue<int>(5);

        // Enqueue elements into the queue
        queue.Enqueue(1);
        queue.Enqueue(2);
        queue.Enqueue(3);

        // Peek at the front element without removing it
        Console.WriteLine("Front element: " + queue.Peek()); // Output: 1

        // Dequeue elements from the queue
        Console.WriteLine("Dequeued: " + queue.Dequeue()); // Output: 1
        Console.WriteLine("Dequeued: " + queue.Dequeue()); // Output: 2

        // Enqueue more elements into the queue
        queue.Enqueue(4);
        queue.Enqueue(5);
        queue.Enqueue(6);
        queue.Enqueue(7);

        // Peek at the front element without removing it
        Console.WriteLine("Front element: " + queue.Peek()); // Output: 3

        // Dequeue elements from the queue
        Console.WriteLine("Dequeued: " + queue.Dequeue()); // Output: 3
        Console.WriteLine("Dequeued: " + queue.Dequeue()); // Output: 4

        // Enqueue another element into the queue
        queue.Enqueue(8);

        // Dequeue and print all remaining elements
        while (!queue.IsEmpty)
        {
            Console.WriteLine("Dequeued: " + queue.Dequeue());
        }

        // This will cause an exception because the queue is empty
        // Uncomment the following line to see the exception
        // Console.WriteLine("Dequeued: " + queue.Dequeue());
    }
}

