﻿using System;
using System.Collections.Generic;

public class TreeNode
{
    public int Val;  // Value of the node
    public TreeNode Left;  // Left child
    public TreeNode Right;  // Right child

    // Constructor to create a new tree node
    public TreeNode(int val)
    {
        Val = val;
        Left = null;
        Right = null;
    }
}

public class BinarySearchTree
{
    private TreeNode root;

    public BinarySearchTree()
    {
        root = null;  // Initializing the root as null
    }

    // Public method to insert a new key into the BST
    public void Insert(int key)
    {
        if (root == null)
        {
            root = new TreeNode(key);  // If the tree is empty, set the root to the new node
        }
        else
        {
            Insert(root, key);  // Otherwise, call the recursive insert method
        }
    }

    // Private helper method to recursively insert a new key
    private void Insert(TreeNode node, int key)
    {
        if (key < node.Val)
        {
            if (node.Left == null)
            {
                node.Left = new TreeNode(key);  // Insert as left child
            }
            else
            {
                Insert(node.Left, key);  // Recur on left subtree
            }
        }
        else
        {
            if (node.Right == null)
            {
                node.Right = new TreeNode(key);  // Insert as right child
            }
            else
            {
                Insert(node.Right, key);  // Recur on right subtree
            }
        }
    }

    // Public method to get the inorder traversal of the BST
    public List<int> InorderTraversal()
    {
        List<int> result = new List<int>();
        InorderTraversal(root, result);  // Call the recursive helper method
        return result;
    }

    // Private helper method to recursively perform inorder traversal
    private void InorderTraversal(TreeNode node, List<int> result)
    {
        if (node != null)
        {
            InorderTraversal(node.Left, result);  // Traverse left subtree
            result.Add(node.Val);  // Visit the node
            InorderTraversal(node.Right, result);  // Traverse right subtree
        }
    }

    // Public method to get the minimum value in the BST
    public int GetMin()
    {
        if (root == null)
        {
            throw new InvalidOperationException("Tree is empty");  // Error if tree is empty
        }
        return GetMin(root);  // Call the recursive helper method
    }

    // Private helper method to find the minimum value in the BST
    private int GetMin(TreeNode node)
    {
        TreeNode current = node;
        while (current.Left != null)
        {
            current = current.Left;  // Move to the leftmost node
        }
        return current.Val;  // Return the value of the leftmost node
    }

    // Public method to get the maximum value in the BST
    public int GetMax()
    {
        if (root == null)
        {
            throw new InvalidOperationException("Tree is empty");  // Error if tree is empty
        }
        return GetMax(root);  // Call the recursive helper method
    }

    // Private helper method to find the maximum value in the BST
    private int GetMax(TreeNode node)
    {
        TreeNode current = node;
        while (current.Right != null)
        {
            current = current.Right;  // Move to the rightmost node
        }
        return current.Val;  // Return the value of the rightmost node
    }

    // Public method to delete a key from the BST
    public void Delete(int key)
    {
        root = Delete(root, key);  // Call the recursive helper method
    }

    // Private helper method to recursively delete a key from the BST
    private TreeNode Delete(TreeNode node, int key)
    {
        if (node == null)
        {
            return node;  // Base case: if the tree is empty
        }

        // Recur down the tree to find the node to be deleted
        if (key < node.Val)
        {
            node.Left = Delete(node.Left, key);  // Recur on the left subtree
        }
        else if (key > node.Val)
        {
            node.Right = Delete(node.Right, key);  // Recur on the right subtree
        }
        else
        {
            // Node with only one child or no child (Case 1 and 2)
            if (node.Left == null)
            {
                return node.Right;  // Return the right child
            }
            else if (node.Right == null)
            {
                return node.Left;  // Return the left child
            }

            // Node with two children (Case 3)
            TreeNode minNode = GetMinNode(node.Right);  // Get the inorder successor (smallest in the right subtree)
            node.Val = minNode.Val;  // Copy the inorder successor's value to this node
            node.Right = Delete(node.Right, minNode.Val);  // Delete the inorder successor
        }
        return node;  // Return the (potentially new) root
    }

    // Private helper method to find the node with the minimum value
    private TreeNode GetMinNode(TreeNode node)
    {
        TreeNode current = node;
        while (current.Left != null)
        {
            current = current.Left;  // Move to the leftmost node
        }
        return current;  // Return the leftmost node
    }
}

// Example usage:
public class Program
{
    public static void Main()
    {
        BinarySearchTree bst = new BinarySearchTree();
        bst.Insert(50);
        bst.Insert(30);
        bst.Insert(20);
        bst.Insert(40);
        bst.Insert(70);
        bst.Insert(60);
        bst.Insert(80);

        Console.WriteLine("Inorder Traversal: " + string.Join(", ", bst.InorderTraversal()));
        Console.WriteLine("Minimum Value: " + bst.GetMin());
        Console.WriteLine("Maximum Value: " + bst.GetMax());

        bst.Delete(20);  // Case 1: Node with no child
        Console.WriteLine("Inorder Traversal after deleting 20: " + string.Join(", ", bst.InorderTraversal()));

        bst.Delete(30);  // Case 2: Node with one child
        Console.WriteLine("Inorder Traversal after deleting 30: " + string.Join(", ", bst.InorderTraversal()));

        bst.Delete(50);  // Case 3: Node with two children
        Console.WriteLine("Inorder Traversal after deleting 50: " + string.Join(", ", bst.InorderTraversal()));
    }
}
