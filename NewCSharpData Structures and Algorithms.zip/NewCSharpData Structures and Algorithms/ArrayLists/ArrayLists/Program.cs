﻿using System;
using System.Collections.Generic;

namespace ArrayLists
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize a list to store Employee objects
            List<Employee> employeeList = new List<Employee>();

            // Add employees to the list
            employeeList.Add(new Employee("Jane", "Jones", 123));
            employeeList.Add(new Employee("John", "Doe", 4567));
            employeeList.Add(new Employee("April", "Redman", 5592));
            employeeList.Add(new Employee("Min", "Joe", 4479));

            // Print all employees in the list
            employeeList.ForEach(employee => Console.WriteLine(employee));

            // Print the second employee in the list (index 1)
            Console.WriteLine(employeeList[1]);

            // Check if the list is empty and print the result
            Console.WriteLine(employeeList.Count == 0);

            // Update the second employee in the list
            employeeList[1] = new Employee("John", "Adams", 4568);

            // Print the total number of employees in the list
            Console.WriteLine(employeeList.Count);

            // Insert a new employee at the fourth position (index 3)
            employeeList.Insert(3, new Employee("John", "Doe", 4567));

            // Print all employees in the list again
            employeeList.ForEach(employee => Console.WriteLine(employee));

            // Convert the list to an array and print each employee in the array
            Employee[] employeeArray = employeeList.ToArray();
            foreach (Employee employee in employeeArray)
            {
                Console.WriteLine(employee);
            }

            // Check if a specific employee is in the list and print the result
            Console.WriteLine(employeeList.Contains(new Employee("Mary", "Smith", 22)));

            // Remove the third employee from the list (index 2)
            employeeList.RemoveAt(2);

            // Print all employees in the list again to show the updated list
            employeeList.ForEach(employee => Console.WriteLine(employee));
        }
    }
}
