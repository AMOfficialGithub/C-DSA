﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayLists
{
    // Define the Employee class with properties and methods
    internal class Employee
    {
        // Properties for the Employee class
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Id { get; set; }

        // Constructor to initialize the properties
        public Employee(string firstName, string lastName, int id)
        {
            FirstName = firstName;
            LastName = lastName;
            Id = id;
        }

        // Override the ToString method to provide a string representation of the Employee object
        public override string ToString()
        {
            return $"Employee{{firstName='{FirstName}', lastName='{LastName}', id={Id}}}";
        }

        // Override the Equals method to compare Employee objects by their properties
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            Employee other = (Employee)obj;
            return Id == other.Id && FirstName == other.FirstName && LastName == other.LastName;
        }

        // Override the GetHashCode method to provide a hash code based on the properties
        public override int GetHashCode()
        {
            return HashCode.Combine(FirstName, LastName, Id);
        }
    }
}

