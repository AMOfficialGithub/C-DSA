﻿//Declaring the array
int[] intArray = { 20, 35, -15, 7, 55, 1, -22 };

//Built in sort method
Array.Sort(intArray);
//Iterating through the unsorted array and displaying it's values
for(int i = 0; i <intArray.Length; i++)
{
    Console.WriteLine(intArray[i]);
}
