﻿using System;

namespace SinglyLinkedList
{
    internal class EmployeeLinkedList
    {
        private EmployeeNode head;

        // Method to add an employee to the front of the list
        public void AddToFront(Employee employee)
        {
            EmployeeNode node = new EmployeeNode(employee);

            // Inserting the node at the front of the list
            node.Next = head; // Set the next reference of the new node to the current head
            head = node; // Update the head to be the new node
        }

        // Method to print the list
        public void PrintList()
        {
            EmployeeNode current = head;
            Console.Write("HEAD -> ");
            while (current != null)
            {
                Console.Write(current + " -> ");
                current = current.Next; // Move to the next node
            }
            Console.WriteLine("null");
        }
    }
}
