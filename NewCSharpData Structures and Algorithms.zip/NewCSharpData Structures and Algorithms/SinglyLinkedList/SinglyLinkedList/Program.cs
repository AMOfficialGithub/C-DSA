﻿using System;
using System.Collections.Generic;

namespace SinglyLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize a linked list to store Employee objects
            EmployeeLinkedList employeeLinkedList = new EmployeeLinkedList();

            // Add employees to the front of the linked list
            employeeLinkedList.AddToFront(new Employee("Jane", "Jones", 123));
            employeeLinkedList.AddToFront(new Employee("Johnson", "Jones", 960));
            employeeLinkedList.AddToFront(new Employee("Rebecca", "Slanders", 844));
            employeeLinkedList.AddToFront(new Employee("Jason", "Dweeb", 692));

            // Print the linked list
            employeeLinkedList.PrintList();
        }
    }
}

