﻿using System;

namespace SinglyLinkedList
{
    internal class EmployeeNode
    {
        public Employee Employee { get; set; }
        public EmployeeNode Next { get; set; }

        // Constructor to initialize the employee node
        public EmployeeNode(Employee employee)
        {
            Employee = employee;
        }

        // Override the ToString method to print employee information
        public override string ToString()
        {
            return Employee.ToString();
        }
    }
}

