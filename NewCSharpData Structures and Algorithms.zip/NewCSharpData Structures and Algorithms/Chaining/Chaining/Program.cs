﻿using System;
using System.Collections.Generic;

public class ChainingHashTable<TKey, TValue>
{
    // Array of linked lists to store key-value pairs
    private LinkedList<KeyValuePair<TKey, TValue>>[] table;
    private int capacity;
    private int count;

    // Constructor to initialize the hash table with a default capacity
    public ChainingHashTable(int capacity = 16)
    {
        this.capacity = capacity;
        table = new LinkedList<KeyValuePair<TKey, TValue>>[capacity];
        count = 0;
    }

    // Property to get the current number of key-value pairs in the hash table
    public int Count => count;

    // Hash function to calculate the index for a given key
    private int Hash(TKey key)
    {
        return (key.GetHashCode() & 0x7fffffff) % capacity;
    }

    // Method to insert a key-value pair into the hash table
    public void Insert(TKey key, TValue value)
    {
        int index = Hash(key);
        if (table[index] == null)
        {
            table[index] = new LinkedList<KeyValuePair<TKey, TValue>>();
        }

        // Check if the key already exists and update its value
        foreach (var pair in table[index])
        {
            if (pair.Key.Equals(key))
            {
                table[index].Remove(pair);
                table[index].AddLast(new KeyValuePair<TKey, TValue>(key, value));
                return;
            }
        }

        // Add the new key-value pair to the linked list
        table[index].AddLast(new KeyValuePair<TKey, TValue>(key, value));
        count++;
    }

    // Method to search for a value by its key
    public TValue Search(TKey key)
    {
        int index = Hash(key);
        if (table[index] != null)
        {
            foreach (var pair in table[index])
            {
                if (pair.Key.Equals(key))
                {
                    return pair.Value;
                }
            }
        }
        return default(TValue);
    }

    // Method to delete a key-value pair by its key
    public void Delete(TKey key)
    {
        int index = Hash(key);
        if (table[index] != null)
        {
            var node = table[index].First;
            while (node != null)
            {
                if (node.Value.Key.Equals(key))
                {
                    table[index].Remove(node);
                    count--;
                    return;
                }
                node = node.Next;
            }
        }
    }
}

class Program
{
    static void Main()
    {
        // Create a hash table
        ChainingHashTable<string, int> hashTable = new ChainingHashTable<string, int>();

        // Insert key-value pairs into the hash table
        hashTable.Insert("one", 1);
        hashTable.Insert("two", 2);
        hashTable.Insert("three", 3);

        // Search for values by their keys
        Console.WriteLine("Value for 'one': " + hashTable.Search("one")); // Output: 1
        Console.WriteLine("Value for 'two': " + hashTable.Search("two")); // Output: 2
        Console.WriteLine("Value for 'three': " + hashTable.Search("three")); // Output: 3

        // Delete a key-value pair by its key
        hashTable.Delete("two");

        // Try to search for the deleted key
        Console.WriteLine("Value for 'two' after deletion: " + hashTable.Search("two")); // Output: 0 (default value)
    }
}

