﻿//Swap Method
//Takes the array to be sorted and two indices representing the elements to swap.
static void Swap(int[] array, int i, int j)
{
    //Check if i equals j
    if (i == j)
    {
        return; //Just return, nothing to do
    }

    //If i doesn't equal j, swap.

    int temp = array[i];
    //assign value at array j to array i
    array[i] = array[j];
    //assign temp to array j
    array[j] = temp;
}

int[] intArray = { 20, 35, -15, 7, 55, 1, -22 };

//Outer Loop
for (int lastUnsortedIndex = intArray.Length - 1; lastUnsortedIndex > 0; lastUnsortedIndex--)
{
    //Inner Loop
    //Compare the value of i to i + 1
    for (int i = 0; i < lastUnsortedIndex; i++)
    {
        if (intArray[i] > intArray[i + 1])
        {
            Swap(intArray, i, i + 1);
        }
    }
}

//Printing the sorted array
foreach (int num in intArray)
{
    Console.WriteLine(num);
}

//To determine time complexity, look at the number of loops.