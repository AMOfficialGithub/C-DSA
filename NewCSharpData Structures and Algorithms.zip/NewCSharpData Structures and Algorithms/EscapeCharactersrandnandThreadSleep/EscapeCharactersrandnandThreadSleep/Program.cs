﻿string myString = "Hi \n Hi";

for(int counter = 10; counter >=0; counter--)
{
    Console.WriteLine("Counting down from {0}",counter);
   
}
//\n stands for new line

// \r\n this works on linux or mac. It is the same as \n 

//Will sleep the application. Do not use it in real-world applications.
Thread.Sleep(1000);