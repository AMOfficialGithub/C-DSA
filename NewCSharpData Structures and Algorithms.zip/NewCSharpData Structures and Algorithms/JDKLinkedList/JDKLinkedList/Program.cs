﻿using System;
using System.Collections.Generic;

namespace LinkedListExample
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create Employee instances
            Employee janeJones = new Employee("Jane", "Jones", 123);
            Employee johnDoe = new Employee("John", "Doe", 4567);
            Employee marySmith = new Employee("Mary", "Smith", 9927);
            Employee mikeWilkons = new Employee("Mike", "Wilkons", 423);

            // Create a LinkedList of Employee objects
            LinkedList<Employee> list = new LinkedList<Employee>();
            list.AddFirst(janeJones);
            list.AddFirst(johnDoe);
            list.AddFirst(marySmith);
            list.AddFirst(mikeWilkons);

            // Iterate through the LinkedList using foreach
            foreach (var employee in list)
            {
                Console.WriteLine(employee);
            }
        }
    }
}
