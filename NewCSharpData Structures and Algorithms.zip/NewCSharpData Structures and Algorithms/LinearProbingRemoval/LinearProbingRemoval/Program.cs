﻿using System;

public class LinearProbingHashTable<TKey, TValue>
{
    private TKey[] keys; // Array to store keys
    private TValue[] values; // Array to store values
    private int capacity; // Capacity of the hash table
    private int count; // Current number of key-value pairs

    public LinearProbingHashTable(int capacity = 16)
    {
        this.capacity = capacity;
        keys = new TKey[capacity];
        values = new TValue[capacity];
        count = 0;
    }

    public int Count => count;

    // Hash function to calculate the index for a given key
    private int Hash(TKey key)
    {
        return (key.GetHashCode() & 0x7fffffff) % capacity;
    }

    // Method to insert a key-value pair into the hash table
    public void Insert(TKey key, TValue value)
    {
        // Resize the hash table if the load factor exceeds 50%
        if (count >= capacity / 2)
        {
            Resize(2 * capacity);
        }

        int index = Hash(key);
        // Use linear probing to find the next available slot
        while (keys[index] != null && !keys[index].Equals(key))
        {
            index = (index + 1) % capacity;
        }

        // Insert the key-value pair
        keys[index] = key;
        values[index] = value;
        count++;
    }

    // Method to search for a value by its key
    public TValue Search(TKey key)
    {
        int index = Hash(key);
        // Use linear probing to find the key
        while (keys[index] != null)
        {
            if (keys[index].Equals(key))
            {
                return values[index];
            }
            index = (index + 1) % capacity;
        }
        // Return the default value if the key is not found
        return default(TValue);
    }

    // Method to delete a key-value pair by its key
    public void Delete(TKey key)
    {
        int index = Hash(key);
        // Use linear probing to find the key
        while (keys[index] != null)
        {
            if (keys[index].Equals(key))
            {
                // Remove the key-value pair
                keys[index] = default(TKey);
                values[index] = default(TValue);
                count--;

                // Reinsert subsequent key-value pairs until an empty slot is found
                index = (index + 1) % capacity;
                while (keys[index] != null)
                {
                    TKey tempKey = keys[index];
                    TValue tempValue = values[index];
                    keys[index] = default(TKey);
                    values[index] = default(TValue);
                    count--;
                    Insert(tempKey, tempValue);
                    index = (index + 1) % capacity;
                }
                return;
            }
            index = (index + 1) % capacity;
        }
    }

    // Method to resize the hash table when the load factor exceeds 50%
    private void Resize(int newCapacity)
    {
        TKey[] oldKeys = keys;
        TValue[] oldValues = values;
        capacity = newCapacity;
        keys = new TKey[newCapacity];
        values = new TValue[newCapacity];
        count = 0;

        // Reinsert all existing key-value pairs
        for (int i = 0; i < oldKeys.Length; i++)
        {
            if (oldKeys[i] != null)
            {
                Insert(oldKeys[i], oldValues[i]);
            }
        }
    }
}

class Program
{
    static void Main()
    {
        // Create a hash table
        LinearProbingHashTable<string, int> hashTable = new LinearProbingHashTable<string, int>();

        // Insert key-value pairs into the hash table
        hashTable.Insert("one", 1);
        hashTable.Insert("two", 2);
        hashTable.Insert("three", 3);

        // Print the current state of the hash table
        Console.WriteLine("Hash table before deletion:");
        PrintHashTable(hashTable);

        // Delete a key-value pair by its key
        hashTable.Delete("two");

        // Print the state of the hash table after deletion
        Console.WriteLine("\nHash table after deletion:");
        PrintHashTable(hashTable);
    }

    static void PrintHashTable<TKey, TValue>(LinearProbingHashTable<TKey, TValue> hashTable)
    {
        // Print key-value pairs in the hash table
        for (int i = 0; i < hashTable.capacity; i++)
        {
            if (hashTable.keys[i] != null)
            {
                Console.WriteLine($"Key: {hashTable.keys[i]}, Value: {hashTable.values[i]}");
            }
        }
    }
}



