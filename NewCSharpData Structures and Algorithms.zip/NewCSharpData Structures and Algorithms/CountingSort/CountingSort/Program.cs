﻿using System;

class Program
{
    static void Main()
    {
        // Initializing the array
        int[] intArray = { 2, 5, 6, 8, 9, 10, 4, 3,2 };

        // Going through the array
        for (int i = 0; i < intArray.Length; i++)
        {
            // Printing the values at each index with i
            Console.WriteLine(intArray[i]);
        }

        // Calling the CountingSort method to sort the array
        CountingSort(intArray, 1, 10);

        Console.WriteLine("Sorted Array:");

        // Printing the sorted array
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]);
        }
    }

    // CountingSort method definition
    static void CountingSort(int[] input, int min, int max)
    {
        // Creating a count array with size based on the range of input values
        int[] countArray = new int[(max - min) + 1];

        // Traversing the input array to populate the count array
        for (int i = 0; i < input.Length; i++)
        {
            countArray[input[i] - min]++;
        }

        // Writing the sorted values back into the input array
        int j = 0;
        for (int i = min; i <= max; i++)
        {
            // Placing each value into the input array based on the count in the count array
            while (countArray[i - min] > 0)
            {
                input[j++] = i;
                countArray[i - min]--;
            }
        }
    }
}
