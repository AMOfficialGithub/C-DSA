﻿using System;
using System.Collections.Generic;

public class Program
{
    public static void Main()
    {
        // Create a HashSet of integers
        HashSet<int> numbers = new HashSet<int>();

        // Add elements to the set
        numbers.Add(1);
        numbers.Add(2);
        numbers.Add(3);
        numbers.Add(4);

        // Try to add a duplicate element (will not be added)
        bool isAdded = numbers.Add(3);
        Console.WriteLine("Element 3 added: " + isAdded); // Output: Element 3 added: False

        // Check if the set contains a specific element
        bool containsTwo = numbers.Contains(2);
        Console.WriteLine("Set contains 2: " + containsTwo); // Output: Set contains 2: True

        // Remove an element from the set
        bool isRemoved = numbers.Remove(4);
        Console.WriteLine("Element 4 removed: " + isRemoved); // Output: Element 4 removed: True

        // Display elements of the set
        Console.WriteLine("Elements in the set:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
        // Output:
        // Elements in the set:
        // 1
        // 2
        // 3

        // Create another set for set operations
        HashSet<int> otherNumbers = new HashSet<int> { 3, 4, 5, 6 };

        // Union operation (numbers U otherNumbers)
        numbers.UnionWith(otherNumbers);
        Console.WriteLine("After UnionWith operation:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
        // Output:
        // After UnionWith operation:
        // 1
        // 2
        // 3
        // 4
        // 5
        // 6

        // Intersect operation (numbers ∩ otherNumbers)
        numbers.IntersectWith(otherNumbers);
        Console.WriteLine("After IntersectWith operation:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
        // Output:
        // After IntersectWith operation:
        // 3
        // 4
        // 5
        // 6

        // Except operation (numbers \ otherNumbers)
        numbers.ExceptWith(new HashSet<int> { 4, 5 });
        Console.WriteLine("After ExceptWith operation:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
        // Output:
        // After ExceptWith operation:
        // 3
        // 6

        // Symmetric Except operation (numbers Δ otherNumbers)
        numbers.SymmetricExceptWith(otherNumbers);
        Console.WriteLine("After SymmetricExceptWith operation:");
        foreach (int number in numbers)
        {
            Console.WriteLine(number);
        }
        // Output:
        // After SymmetricExceptWith operation:
        // 4
        // 5
    }
}

