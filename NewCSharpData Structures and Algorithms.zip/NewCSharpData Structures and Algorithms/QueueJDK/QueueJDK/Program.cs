﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        // Create a queue of integers
        Queue<int> queue = new Queue<int>();

        // Enqueue elements
        queue.Enqueue(10);
        queue.Enqueue(20);
        queue.Enqueue(30);

        // Peek at the front element
        Console.WriteLine("Front element: " + queue.Peek()); // Output: 10

        // Dequeue elements
        Console.WriteLine("Dequeued: " + queue.Dequeue()); // Output: 10
        Console.WriteLine("Dequeued: " + queue.Dequeue()); // Output: 20

        // Check if the queue is empty
        Console.WriteLine("Is queue empty? " + (queue.Count == 0)); // Output: False

        // Dequeue the last element
        Console.WriteLine("Dequeued: " + queue.Dequeue()); // Output: 30

        // Check if the queue is empty
        Console.WriteLine("Is queue empty? " + (queue.Count == 0)); // Output: True

        // Clear the queue
        queue.Clear();
        Console.WriteLine("Queue cleared. Is queue empty? " + (queue.Count == 0)); // Output: True
    }
}

