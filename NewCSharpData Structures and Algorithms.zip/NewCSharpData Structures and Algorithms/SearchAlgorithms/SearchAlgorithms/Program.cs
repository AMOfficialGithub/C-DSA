﻿using System;

class Program
{
    static void Main()
    {
        // Linear Search
        int[] intArray = { 5, 47, 89, 100, 273, 16, 3, 12 };
        // Testing LinearSearch with different values
        Console.WriteLine(LinearSearch(intArray, -15)); // Output: -1 (not found)
        Console.WriteLine(LinearSearch(intArray, 1));   // Output: -1 (not found)
        Console.WriteLine(LinearSearch(intArray, 273)); // Output: 4 (found at index 4)
        Console.WriteLine(LinearSearch(intArray, 100)); // Output: 3 (found at index 3)

        // Iterative Binary Search
        int[] intArray1 = { -22, -15, 1, 7, 20, 35, 55 };
        // Testing IterativeBinarySearch with different values
        Console.WriteLine(IterativeBinarySearch(intArray1, -15)); // Output: 1 (found at index 1)
        Console.WriteLine(IterativeBinarySearch(intArray1, 35));  // Output: 5 (found at index 5)
        Console.WriteLine(IterativeBinarySearch(intArray1, 888)); // Output: -1 (not found)
        Console.WriteLine(IterativeBinarySearch(intArray1, 1));   // Output: 2 (found at index 2)

        // Recursive Binary Search
        // Testing RecursiveBinarySearch with different values
        Console.WriteLine(RecursiveBinarySearch(intArray1, -15)); // Output: 1 (found at index 1)
        Console.WriteLine(RecursiveBinarySearch(intArray1, 35));  // Output: 5 (found at index 5)
        Console.WriteLine(RecursiveBinarySearch(intArray1, 888)); // Output: -1 (not found)
        Console.WriteLine(RecursiveBinarySearch(intArray1, 1));   // Output: 2 (found at index 2)
    }

    // Linear Search Algorithm
    static int LinearSearch(int[] input, int value)
    {
        // Iterate through each element in the array
        for (int i = 0; i < input.Length; i++)
        {
            // If the current element is equal to the search value, return the index
            if (input[i] == value)
                return i;
        }
        // If the value is not found, return -1
        return -1;
    }

    // Iterative Binary Search Algorithm
    static int IterativeBinarySearch(int[] input, int value)
    {
        int start = 0;
        int end = input.Length;
        while (start < end)
        {
            // Calculate the midpoint of the current search range
            int midpoint = (start + end) / 2;
            // Print the midpoint for debugging purposes
            Console.WriteLine("Midpoint= " + midpoint);
            // Check if the midpoint element is equal to the search value
            if (input[midpoint] == value)
            {
                return midpoint; // Return the index if found
            }
            // If the search value is greater, adjust the start index to search the right half
            else if (input[midpoint] < value)
            {
                start = midpoint + 1;
            }
            // If the search value is smaller, adjust the end index to search the left half
            else
            {
                end = midpoint;
            }
        }
        // If the value is not found, return -1
        return -1;
    }

    // Recursive Binary Search Algorithm
    static int RecursiveBinarySearch(int[] input, int value)
    {
        // Call the recursive helper method with the initial search range
        return RecursiveBinarySearch(input, 0, input.Length, value);
    }

    static int RecursiveBinarySearch(int[] input, int start, int end, int value)
    {
        // Base case: if the search range is empty, return -1
        if (start >= end)
        {
            return -1;
        }

        // Calculate the midpoint of the current search range
        int midpoint = (start + end) / 2;

        // Check if the midpoint element is equal to the search value
        if (input[midpoint] == value)
        {
            return midpoint; // Return the index if found
        }
        // If the search value is greater, search the right half recursively
        else if (input[midpoint] < value)
        {
            return RecursiveBinarySearch(input, midpoint + 1, end, value);
        }
        // If the search value is smaller, search the left half recursively
        else
        {
            return RecursiveBinarySearch(input, start, midpoint, value);
        }
    }
}
