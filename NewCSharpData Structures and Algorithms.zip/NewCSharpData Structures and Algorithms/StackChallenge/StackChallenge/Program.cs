﻿using System;
using System.Collections.Generic;

class Program
{
    static bool IsPalindrome(string input)
    {
        // Normalize the string
        string normalized = NormalizeString(input);

        // Initialize the stack
        Stack<char> stack = new Stack<char>();

        // Find the midpoint of the string
        int length = normalized.Length;
        int midpoint = length / 2;

        // Push the first half of the string onto the stack
        for (int i = 0; i < midpoint; i++)
        {
            stack.Push(normalized[i]);
        }

        // If the length is odd, skip the middle character
        if (length % 2 != 0)
        {
            midpoint++;
        }

        // Compare the second half of the string with the stack
        for (int i = midpoint; i < length; i++)
        {
            if (stack.Pop() != normalized[i])
            {
                return false;
            }
        }

        return true;
    }

    static string NormalizeString(string input)
    {
        var chars = new List<char>();
        foreach (char ch in input)
        {
            if (char.IsLetterOrDigit(ch))
            {
                chars.Add(char.ToLower(ch));
            }
        }
        return new string(chars.ToArray());
    }

    static void Main()
    {
        string input = "A man, a plan, a canal, Panama!";
        bool result = IsPalindrome(input);
        Console.WriteLine($"Is the string \"{input}\" a palindrome? {result}");
    }
}

