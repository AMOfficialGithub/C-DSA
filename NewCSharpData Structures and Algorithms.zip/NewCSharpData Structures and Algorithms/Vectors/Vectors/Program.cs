﻿using System;
using System.Collections.Generic;

namespace Vectors
{
    class Program
    {
        static void Main(string[] args)
        {
            // Initialize a list to store Employee objects
            List<Employee> employeeList = new List<Employee>();

            // Add employees to the list
            employeeList.Add(new Employee("Jane", "Jones", 123));
            employeeList.Add(new Employee("Johnson", "Jones", 960));
            employeeList.Add(new Employee("Rebecca", "Slanders", 844));
            employeeList.Add(new Employee("Jason", "Dweeb", 692));

            // Print all employees in the list
            employeeList.ForEach(employee => Console.WriteLine(employee));
        }
    }
}

