﻿//The array to be sorted
int[] intArray = { 20, 35, -15, 7, 55, 1, -22 };

//Beginning of the implementation the entire array is unsorted.
//the last unsorted index will be the last valid index, which is 6 for this array.
//Keep going as lastUnsorted index is greater than 0
//Decrement from the right of the array.
//This outer loop is increasing the partion by one
for(int lastUnsortedIndex = intArray.Length - 1; lastUnsortedIndex > 0; lastUnsortedIndex--)
{
    int largest = 0; //Largest petition
    //1 is where the position is starting
    //Increments to the right by 1
    //Compare every element against the largest
    //This inner loop is looking for the largest
    for(int i= 1; i <= lastUnsortedIndex; i++)
    {
        if (intArray[i] > intArray[largest])
        {
            //Update largest to the i
            largest = i;
        }
    }
    //
    Swap(intArray, largest, lastUnsortedIndex);
}



//Traversing the array below
//Starts at index zero, as long as i is less than the
//array, increment to the right
for(int i = 0; i <intArray.Length;i++)
{
    //Prints out the unsorted numbers in the array
    Console.WriteLine(intArray[i]);
}

//The actual swap method

static void Swap(int[]array, int i, int j)
{
    if(i==j)
    {
        return;
    }
    int temp = array[i];
    array[i] = array[j];
    array[j] = temp;
}
