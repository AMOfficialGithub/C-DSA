﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int[] intArray = { 20, 35, -15, 1, -22 };

        // Print the original array
        Console.WriteLine("Original array:");
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]);
        }

        // Call the recursive insertion sort method
        InsertionSort(intArray, intArray.Length);

        // Print the sorted array
        Console.WriteLine("\nSorted Array:");
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]);
        }
    }

    // Recursive insertion sort method
    public static void InsertionSort(int[] input, int numItems)
    {
        // Base case: if the array has less than 2 elements, it's already sorted
        if (numItems < 2)
        {
            return;
        }

        // Sort the first numItems - 1 elements
        InsertionSort(input, numItems - 1);

        // Insert the last element of the sorted portion into its correct position
        int newElement = input[numItems - 1];
        int i = numItems - 1;

        // Shift elements to the right to make space for the new element
        while (i > 0 && input[i - 1] > newElement)
        {
            input[i] = input[i - 1];
            i--;
        }

        // Place the new element in its correct position
        input[i] = newElement;
    }
}

