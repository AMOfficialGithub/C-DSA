﻿//6-9-2024
//An algorithmn can be a recipe for a computer to follow. 
//It's a set of instructions that a computer will follow step-by-step to solve a problem.

//Algorithmns take an input and produce an output. The output will be the answer to a question regarding the input.
//Let's say you have a non-empty array of positive integers called nums, and wanted to answer the question,
//"What is the largest number in nums?"
//You could write an algorithmn that takes an array called nums as input, and outputs the largest number in nums.

int maxNum = 0;

int[] nums = new int[5] { 12, 2, 45, 100, 99};

foreach(int num in nums)
{
    if(num > maxNum)
    {
        maxNum = num;
    }
   
}
//Printing this outside of the foreach will gaurantee that only the largest number is shown
//Not the largest number in each iteration
Console.WriteLine("The maximum number is {0}", maxNum);