﻿using System;
using System.Collections.Generic;

public class MaxHeap
{
    // The heap is represented as a List of integers
    private List<int> heap = new List<int>();

    // Insert an element into the heap
    public void Insert(int element)
    {
        // Add the new element to the end of the list
        heap.Add(element);
        // Restore the heap property by moving the new element up
        HeapifyUp(heap.Count - 1);
    }

    // Delete the root element from the heap
    public int Delete()
    {
        // If the heap is empty, throw an exception
        if (heap.Count == 0) throw new InvalidOperationException("Heap is empty");

        // Store the root element (which will be removed)
        int root = heap[0];
        // Replace the root with the last element in the list
        heap[0] = heap[heap.Count - 1];
        // Remove the last element from the list
        heap.RemoveAt(heap.Count - 1);
        // Restore the heap property by moving the new root down
        HeapifyDown(0);

        // Return the original root element
        return root;
    }

    // Peek at the root element without removing it
    public int Peek()
    {
        // If the heap is empty, throw an exception
        if (heap.Count == 0) throw new InvalidOperationException("Heap is empty");
        // Return the root element
        return heap[0];
    }

    // Heapify up from the given index
    private void HeapifyUp(int index)
    {
        // Continue until we reach the root (index 0)
        while (index > 0)
        {
            // Calculate the parent's index
            int parentIndex = (index - 1) / 2;
            // If the current element is less than or equal to its parent, we're done
            if (heap[index] <= heap[parentIndex]) break;

            // Swap the current element with its parent
            Swap(index, parentIndex);
            // Move up to the parent's index
            index = parentIndex;
        }
    }

    // Heapify down from the given index
    private void HeapifyDown(int index)
    {
        // Calculate the last index in the list
        int lastIndex = heap.Count - 1;
        // Continue until we reach the bottom of the heap
        while (index < lastIndex)
        {
            // Calculate the indices of the left and right children
            int leftChild = 2 * index + 1;
            int rightChild = 2 * index + 2;
            // Assume the current element is the largest
            int largest = index;

            // If the left child exists and is larger, update the largest index
            if (leftChild <= lastIndex && heap[leftChild] > heap[largest])
                largest = leftChild;

            // If the right child exists and is larger, update the largest index
            if (rightChild <= lastIndex && heap[rightChild] > heap[largest])
                largest = rightChild;

            // If the current element is larger than both children, we're done
            if (largest == index) break;

            // Swap the current element with the largest child
            Swap(index, largest);
            // Move down to the largest child's index
            index = largest;
        }
    }

    // Swap elements at the given indices
    private void Swap(int index1, int index2)
    {
        // Swap the elements at index1 and index2
        int temp = heap[index1];
        heap[index1] = heap[index2];
        heap[index2] = temp;
    }
}

// Example usage
public class Program
{
    public static void Main()
    {
        // Create a new max-heap
        MaxHeap maxHeap = new MaxHeap();

        // Insert elements into the heap
        maxHeap.Insert(10);
        maxHeap.Insert(4);
        maxHeap.Insert(15);
        maxHeap.Insert(20);
        maxHeap.Insert(30);

        // Peek at the maximum element
        Console.WriteLine("Peek: " + maxHeap.Peek()); // Output: 30

        // Delete the maximum element
        Console.WriteLine("Deleted: " + maxHeap.Delete()); // Output: 30

        // Peek at the new maximum element
        Console.WriteLine("Peek: " + maxHeap.Peek()); // Output: 20
    }
}

