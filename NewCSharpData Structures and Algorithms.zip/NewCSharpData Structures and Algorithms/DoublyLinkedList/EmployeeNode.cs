package academy.learnprogramming.doublylinkedlists;

public class EmployeeNode {

    private Employee employee;
    private EmployeeNode next;
    private EmployeeNode previous;

    public EmployeeNode(Employee employee) {
        this.employee = employee;
    }

    public Employee GetEmployee() {
        return employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }

    public EmployeeNode GetNext() {
        return next;
    }

    public void SetNext(EmployeeNode next) {
        this.next = next;
    }

    public EmployeeNode GetPrevious() {
        return previous;
    }

    public void SetPrevious(EmployeeNode previous) {
        this.previous = previous;
    }

    public String ToString() {
        return employee.ToString();
    }

}
