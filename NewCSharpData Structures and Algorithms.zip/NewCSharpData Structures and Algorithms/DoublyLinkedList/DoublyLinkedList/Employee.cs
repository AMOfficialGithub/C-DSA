﻿using System;

namespace DoublyLinkedList
{
    internal class Employee
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int Id { get; set; }

        public Employee(string firstName, string lastName, int id)
        {
            FirstName = firstName;
            LastName = lastName;
            Id = id;
        }

        public override string ToString()
        {
            return $"Employee{{firstName='{FirstName}', lastName='{LastName}', id={Id}}}";
        }
    }
}


