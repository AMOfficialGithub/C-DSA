﻿using System;

namespace DoublyLinkedList
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeDoublyLinkedList list = new EmployeeDoublyLinkedList();

            list.AddToFront(new Employee("Jane", "Jones", 123));
            list.AddToFront(new Employee("John", "Doe", 4567));
            list.AddToEnd(new Employee("Rebecca", "Slanders", 844));
            list.AddToEnd(new Employee("Jason", "Dweeb", 692));

            Console.WriteLine("Initial list:");
            list.PrintList();

            list.RemoveFromFront();
            Console.WriteLine("After removing from front:");
            list.PrintList();

            list.RemoveFromEnd();
            Console.WriteLine("After removing from end:");
            list.PrintList();

            Console.WriteLine("List size: " + list.GetSize());
        }
    }
}



