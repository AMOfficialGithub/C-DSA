﻿using System;

namespace DoublyLinkedList
{
    internal class EmployeeDoublyLinkedList
    {
        private EmployeeNode head;
        private EmployeeNode tail;
        private int size;

        public void AddToFront(Employee employee)
        {
            EmployeeNode node = new EmployeeNode(employee);

            if (head == null)
            {
                tail = node;
            }
            else
            {
                head.Previous = node;
                node.Next = head;
            }

            head = node;
            size++;
        }

        public void AddToEnd(Employee employee)
        {
            EmployeeNode node = new EmployeeNode(employee);

            if (tail == null)
            {
                head = node;
            }
            else
            {
                tail.Next = node;
                node.Previous = tail;
            }

            tail = node;
            size++;
        }

        public EmployeeNode RemoveFromFront()
        {
            if (IsEmpty())
            {
                return null;
            }

            EmployeeNode removedNode = head;

            if (head.Next == null)
            {
                tail = null;
            }
            else
            {
                head.Next.Previous = null;
            }

            head = head.Next;
            size--;
            removedNode.Next = null;
            return removedNode;
        }

        public EmployeeNode RemoveFromEnd()
        {
            if (IsEmpty())
            {
                return null;
            }

            EmployeeNode removedNode = tail;

            if (tail.Previous == null)
            {
                head = null;
            }
            else
            {
                tail.Previous.Next = null;
            }

            tail = tail.Previous;
            size--;
            removedNode.Previous = null;
            return removedNode;
        }

        public int GetSize()
        {
            return size;
        }

        public bool IsEmpty()
        {
            return head == null;
        }

        public void PrintList()
        {
            EmployeeNode current = head;
            Console.Write("HEAD -> ");
            while (current != null)
            {
                Console.Write(current + " <=> ");
                current = current.Next;
            }
            Console.WriteLine("null");
        }
    }
}


