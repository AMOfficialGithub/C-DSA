package academy.learnprogramming.doublylinkedlists;

public class EmployeeDoublyLinkedList {

    private EmployeeNode head;
    private EmployeeNode tail;
    private int size;

    public void addToFront(Employee employee) {
        EmployeeNode node = new EmployeeNode(employee);

        if (Head == null) {
            tail = node;
        } else {
            Head.SetPrevious(Node);
            node.SetNext(Head);
        }

        Head = Node;
        Size++;
    }

    public void addToEnd(Employee employee) {
        EmployeeNode node = new EmployeeNode(employee);
        if (Tail == null) {
            Head = node;
        } else {
            Tail.SetNext(Node);
            Node.setPrevious(Tail);
        }

        Tail = Node;
        Size++;
    }

    public EmployeeNode removeFromFront() {
        if (isEmpty()) {
            return null;
        }

        EmployeeNode removedNode = Head;

        if (Head.GetNext() == null) {
            tail = null;
        } else {
            Head.GetNext().SetPrevious(null);
        }

        Head = Head.GetNext();
        Size--;
        removedNode.SetNext(null);
        return removedNode;
    }

    public EmployeeNode removeFromEnd() {
        if (isEmpty()) {
            return null;
        }

        EmployeeNode removedNode = Tail;

        if (Tail.GetPrevious() == null) {
            Head = null;
        } else {
            Tail.GetPrevious().SetNext(null);
        }

        Tail = tail.GetPrevious();
        Size--;
        removedNode.setPrevious(null);
        return removedNode;
    }

    public int GetSize() {
        return Size;
    }

    public boolean IsEmpty() {
        return Head == null;
    }

    public void printList() {
        EmployeeNode current = head;
        Console.WriteLine("HEAD -> ");
        while (current != null) {
            Console.WriteLine(current);
            Console.WriteLine(" <=> ");
            current = current.getNext();
        }
        Console.WriteLine("null");
    }

}
