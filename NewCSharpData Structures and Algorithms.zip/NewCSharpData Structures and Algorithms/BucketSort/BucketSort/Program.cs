﻿using System;
using System.Collections.Generic;

public class BucketSorter
{
    // Method to perform bucket sort on an array of floating-point numbers
    public static void BucketSort(float[] array, int bucketCount = 5)
    {
        // Check if the array is empty or null
        if (array == null || array.Length == 0)
        {
            return;
        }

        // Step 1: Create empty buckets
        List<float>[] buckets = new List<float>[bucketCount];
        for (int i = 0; i < bucketCount; i++)
        {
            buckets[i] = new List<float>();
        }

        // Step 2: Distribute elements into buckets
        foreach (float element in array)
        {
            // Calculate the bucket index
            int bucketIndex = (int)(element * bucketCount);
            // Add the element to the appropriate bucket
            buckets[bucketIndex].Add(element);
        }

        // Step 3: Sort each bucket
        for (int i = 0; i < bucketCount; i++)
        {
            buckets[i].Sort();
        }

        // Step 4: Concatenate buckets
        int index = 0;
        for (int i = 0; i < bucketCount; i++)
        {
            foreach (float element in buckets[i])
            {
                array[index++] = element;
            }
        }
    }
}

class Program
{
    static void Main()
    {
        // Example array of floating-point numbers
        float[] array = { 0.42f, 0.32f, 0.23f, 0.52f, 0.25f, 0.47f, 0.51f };

        // Print the original array
        Console.WriteLine("Original array:");
        foreach (var item in array)
        {
            Console.Write(item + " ");
        }
        Console.WriteLine();

        // Perform bucket sort
        BucketSorter.BucketSort(array);

        // Print the sorted array
        Console.WriteLine("Sorted array:");
        foreach (var item in array)
        {
            Console.Write(item + " ");
        }
        Console.WriteLine();
    }
}

