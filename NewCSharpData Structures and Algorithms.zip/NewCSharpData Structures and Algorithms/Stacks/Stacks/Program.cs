﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main()
    {
        Stack<int> stack = new Stack<int>();

        // Push elements onto the stack
        stack.Push(1);
        stack.Push(2);
        stack.Push(3);

        // Peek at the top element
        Console.WriteLine("Top element: " + stack.Peek()); // Output: 3

        // Pop elements from the stack
        Console.WriteLine("Popped: " + stack.Pop()); // Output: 3
        Console.WriteLine("Popped: " + stack.Pop()); // Output: 2

        // Check if the stack is empty
        Console.WriteLine("Is stack empty? " + (stack.Count == 0)); // Output: False

        // Pop the last element
        Console.WriteLine("Popped: " + stack.Pop()); // Output: 1

        // Check if the stack is empty
        Console.WriteLine("Is stack empty? " + (stack.Count == 0)); // Output: True
    }
}

