﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Define the array to be sorted
        int[] intArray = { 20, 35, -15, 7, 55, 1, -22 };

        // Traversing through the array and printing out the value of each element
        Console.WriteLine("Original array:");
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]);
        }

        // Calling the MergeSort method to sort the array
        MergeSort(intArray, 0, intArray.Length);

        // Printing the sorted array
        Console.WriteLine("\nSorted array:");
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]);
        }
    }

    // MergeSort method to recursively divide and merge the array
    static void MergeSort(int[] input, int start, int end)
    {
        // Need a breaking condition for the recursive method
        if (end - start < 2)
        {
            return;
        }

        // Partitioning: Find the middle index of the array
        int mid = (start + end) / 2;
        // Recursively call MergeSort on the left half of the array
        MergeSort(input, start, mid);
        // Recursively call MergeSort on the right half of the array
        MergeSort(input, mid, end);
        // Merge sorted partitions
        Merge(input, start, mid, end);
    }

    // Merge method to merge two sorted subarrays into a single sorted array
    static void Merge(int[] input, int start, int mid, int end)
    {
        // Check if the last element of the left subarray is less than or equal to the first element of the right subarray
        if (input[mid - 1] <= input[mid])
        {
            return; // If true, the arrays are already sorted and no merging is needed
        }

        // Initialize indices for the left subarray, right subarray, and temporary array
        int i = start; // Index for the left subarray
        int j = mid; // Index for the right subarray
        int tempIndex = 0; // Index for the temporary array

        // Create a temporary array to store the merged elements
        int[] temp = new int[end - start];

        // Compare elements from the left and right subarrays and merge them into the temporary array
        while (i < mid && j < end)
        {
            temp[tempIndex++] = input[i] <= input[j] ? input[i++] : input[j++];
        }

        // Copy any remaining elements from the left subarray into the temporary array
        Array.Copy(input, i, input, start + tempIndex, mid - i);
        // Copy the merged elements from the temporary array back into the original array
        Array.Copy(temp, 0, input, start, tempIndex);
    }
}


