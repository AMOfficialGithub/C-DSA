﻿//Calculate the factorial in an interative fashion. No recursion below
static int iterativeFactorial(int num)
{
    if(num == 0)
    {
        return 1;
    }
    int factorial = 1;
    for(int i = 1; i <=num; i++)
    {
        factorial *= i; // 1 * 1 == 2. i becomes 2, so 2 *2, then 3 * 2 etc.
    }
    return factorial;
}

//With recursion

//1! = 0! * 1 = 1
//2! = 2 * 1 =  2 *1
//3! = 3! * @ * 1 =  3 * 2

//Multiply the number by n -1 factorial.
//n! = n * (n-1)!


//recursiveFactorial(3)
static int recursiveFactorial(int num)
{
    //Breaking condition known as the "base case"
    if (num == 0)
    {
        
        return 1;
    }

    return num * recursiveFactorial(num - 1);
}

