﻿//Creating Array

int[] intArray = { -22, -15, 30, 45, 89, 100 };


//Looping through the array to print its value at the position of i
for(int i = 0; i <intArray.Length; i++)
{
    Console.WriteLine(intArray[i]);
}

//Swap method is not needed for shell sort

//Initailize gap value and reduce it for each iteration
//Take the length of the array and divide it by two
//As long as the gap is larger than 0, the final iteration must always have a gap of one
//On each iteration divide the gap value by 2.
for(int gap = intArray.Length / 2; gap > 0; gap /=2)
{
    //Code the actual comparing and shifting below.
    //Insertion sort using gap below.
    //intArray.Length is to look at all the values in the array
    for(int i = gap; i < intArray.Length; i++)
    {
        int newElement = intArray[i];

        int j = i; //used for traversing

        while(j >= gap && intArray[j-gap] > newElement)
        {
            intArray[j] = intArray[j - gap];//Assign int array j with int array (45) - 0
            j -= gap;
        }
        intArray[j] = newElement;
    }
}