﻿using System;

class Program
{
    static void Main(string[] args)
    {
        int[] intArray = { 20, 35, -15, 1, -22 };

        // Looping through the array
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]); // This prints out the values of the index
        }

        // The first unsorted index starts at 1, with 0 already sorted
        // Will keep going as long as firstUnsortedIndex is less than the array length
        // FirstUnsortedIndex increasing by one
        // OuterLoop is growing the position by one
        for (int firstUnsortedIndex = 1; firstUnsortedIndex < intArray.Length; firstUnsortedIndex++)
        {
            int newElement = intArray[firstUnsortedIndex];

            int i = firstUnsortedIndex;
            // Looking for the insertion position, as long as the front of the array is not hit
            for (; i > 0 && intArray[i - 1] > newElement; i--)
            {
                // Shifting from right to left
                intArray[i] = intArray[i - 1];
            }

            intArray[i] = newElement;
        }

        // Printing the sorted array
        Console.WriteLine("\nSorted Array:");
        for (int i = 0; i < intArray.Length; i++)
        {
            Console.WriteLine(intArray[i]);
        }
    }
}

